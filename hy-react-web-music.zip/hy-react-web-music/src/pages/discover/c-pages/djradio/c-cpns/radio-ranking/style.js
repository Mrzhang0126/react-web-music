import styled from 'styled-components';

export const RankingWraper = styled.div`
  .ranking-list {
    display: flex;
    justify-content: space-between;
    flex-wrap: wrap;
  }
`