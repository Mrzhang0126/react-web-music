export const HOT_RECOMMEND_LIMIT = 8;

export const NEW_ALBUM_PAGE_NUM = 2;
export const NEW_ALBUM_PER_PAGE = 5;
