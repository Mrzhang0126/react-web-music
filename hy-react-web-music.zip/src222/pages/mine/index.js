import React, { memo } from 'react';

export default memo(function Mine() {
  return (
    <div>
      <h2>Mine</h2>
    </div>
  )
})

