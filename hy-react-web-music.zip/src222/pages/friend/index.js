import React, { memo } from 'react';

export default memo(function Friend() {
  return (
    <div>
      <h2>Friend</h2>
    </div>
  )
})

