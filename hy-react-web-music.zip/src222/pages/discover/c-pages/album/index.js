import React, { memo } from 'react'

export default memo(function Album() {
  return (
    <div>
      <h2>Album</h2>
    </div>
  )
})
