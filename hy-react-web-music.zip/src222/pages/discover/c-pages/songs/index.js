import React, { memo } from 'react'

export default memo(function Songs() {
  return (
    <div>
      <h2>Songs</h2>
    </div>
  )
})
