import React, { memo } from 'react';

export default memo(function RankingList() {
  return (
    <div>
      <h2>RankingList</h2>
    </div>
  )
})
