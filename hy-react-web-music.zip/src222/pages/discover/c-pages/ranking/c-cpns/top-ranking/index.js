import React, { memo } from 'react';

export default memo(function TopRanking() {
  return (
    <div>
      <h2>TopRanking</h2>
    </div>
  )
})
