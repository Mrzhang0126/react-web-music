import React, { memo } from 'react';

export default memo(function RankingHeader() {
  return (
    <div>
      <h2>RankingHeader</h2>
    </div>
  )
})
