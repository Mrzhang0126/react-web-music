import React, { memo } from 'react'

export default memo(function HotAnchor() {
  return (
    <div>
      <h2>HotAnchor</h2>
    </div>
  )
})
