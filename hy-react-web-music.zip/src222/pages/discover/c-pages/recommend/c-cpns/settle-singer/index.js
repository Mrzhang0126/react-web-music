import React, { memo } from 'react'

export default memo(function SettleSinger() {
  return (
    <div>
      <h2>SettleSinger</h2>
    </div>
  )
})
