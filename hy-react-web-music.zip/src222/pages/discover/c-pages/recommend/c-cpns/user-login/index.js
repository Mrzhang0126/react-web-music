import React, { memo } from 'react'

export default memo(function UserLogin() {
  return (
    <div>
      <h2>UserLogin</h2>
    </div>
  )
})
