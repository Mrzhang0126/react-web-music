import React, { memo } from 'react'

export default memo(function Artist() {
  return (
    <div>
      <h2>Artist</h2>
    </div>
  )
})
