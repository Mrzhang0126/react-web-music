import React, { memo } from 'react'

export default memo(function Djradio() {
  return (
    <div>
      <h2>Djradio</h2>
    </div>
  )
})
