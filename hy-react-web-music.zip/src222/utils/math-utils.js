export function getRandomNumber(num) {
  return Math.floor(Math.random() * num);
}